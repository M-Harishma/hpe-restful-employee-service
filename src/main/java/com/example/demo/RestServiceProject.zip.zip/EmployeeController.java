package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
    private final EmployeeManager employeeManager = new EmployeeManager();
    @GetMapping ("/employees")
    public Employees getEmployees(){
        return employeeManager.getEmployees();
    }
  
   
}
